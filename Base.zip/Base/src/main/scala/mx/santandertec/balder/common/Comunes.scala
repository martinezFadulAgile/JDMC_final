package mx.santandertec.balder.common

import org.apache.spark.sql.SparkSession

object Comunes {

}

