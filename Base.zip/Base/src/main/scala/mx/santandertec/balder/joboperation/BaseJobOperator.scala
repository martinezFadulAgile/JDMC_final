package mx.santandertec.balder.joboperation

import org.apache.spark.sql.SparkSession

object BaseJobOperator {
  def main(args: Array[String]) {
    val spark = SparkSession.
      builder().
      appName("Spark BALDER").
      config("spark.sql.warehouse.dir", "spark-warehouse").
      enableHiveSupport().
      getOrCreate()
    println("===INICIA PROCESO===")
    val dfQuery = spark.sql("select * from imr_prueba.imr")
    dfQuery.show()
  }
}
