package mx.santandertec.balder.job

import org.apache.spark.sql.SparkSession
/**
 * Object donde se definen los tipos de flujo
 */
object FlujosJob {

}